function Attribution() {
   return (
      <footer className="attribution">
         <p>developed by <a href="https://x1-il.netlify.app" target="_blank" rel="noreferrer">X1-Il</a></p>
      </footer>
   );
}

export default Attribution;
